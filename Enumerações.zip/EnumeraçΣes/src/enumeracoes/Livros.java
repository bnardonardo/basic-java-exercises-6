package enumeracoes;

public enum Livros {
    JCP ("Java Como Programar", 2010),
    CCP ("C Como Programar", 2007),
    cormen ("Algoritmos Teoria e Prática", 1989),
    POO ("Programação Orientada ao Objeto", 2015),
    IPOOUJ ("Introdução a Programação Orientada ao Objeto Usando Java", 2013);
    
    private final String titulo;
    private final int ano;
    
    Livros (String titulo, int ano){
        this.titulo=titulo;
        this.ano=ano;
    }
    public String getTitulo(){
        return titulo;
    }
    public int getAno(){
        return ano;
    }
}
