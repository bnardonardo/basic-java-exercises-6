package enumeracoes;
import java.util.EnumSet;

public class Main {
    
    public static void main(String[] args) {
        //System.out.println("Hello, World!");
        Livros L;
        L = Livros.POO;
        System.out.printf ("%s-%s, %d \n", L, L.getTitulo(), L.getAno());
        
        //primeiro for values, para mostrar tds
								System.out.printf ("\nMostrar tds os livros\n");
        for (Livros M: Livros.values()){            
            System.out.printf ("%s-%s, %d\n", M, M.getTitulo(), M.getAno());
    }
    
        //segundo for, mostra por range
        System.out.printf ("\nMostrar os livros por range (CCP ao POO) \n");       
        for (Livros N : EnumSet.range(Livros.CCP, Livros.POO)){
        System.out.printf ("%s-%s, %d\n", N, N.getTitulo(), N.getAno());
        }
    }
}
