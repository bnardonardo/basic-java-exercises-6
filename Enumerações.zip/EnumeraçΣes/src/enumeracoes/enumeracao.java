package enumeracoes;

public class enumeracao {
    
}
