package datanovo;
import java.util.GregorianCalendar;
import java.util.Calendar;

public class Data {
    private int dia;
    private Meses mes;
    private int ano;
    public int i;
    public int cont;
    
    public Data (){
        dia=0;
        ano=0;
    }
    
    public Data (int dia, int mes, int ano){
        setDia(dia);
        setAno(ano);
    }
    
    public void setDia(int dia){
        this.dia = Meses.getDias();
    }
    
    public void setAno (int ano){
        if (ano<= 0) this.ano=1;
        else this.ano=ano;
    }
    
    public int getDia(){
        return dia;
    }
    
    public int getAno(){
        return ano;
    }
    
    public Data (int i, int cont){
        this.i=i;
        this.cont=cont;
    }
}
