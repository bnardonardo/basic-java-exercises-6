package enummeses;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        Meses M1;
        M1=Meses.JAN;
        System.out.printf ("%s - Mês de %s possui %s dias", M1, M1.getNome(), M1.getNumDias());
    }
    
}
