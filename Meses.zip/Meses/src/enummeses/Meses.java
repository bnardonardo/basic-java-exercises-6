package enummeses;

public enum Meses {
    JAN ("Janeiro", 31),
    FEV ("Fevereiro", 28),
    MAR ("Março", 31),
    ABR ("Abril", 30),
    MAI ("Maio", 31),
    JUN ("Junho", 30),
    JUL ("Julho", 31),
    AGO ("Agosto", 31),
    SET ("Setembro", 30),
    OUT ("Outubro", 31),
    NOV ("Novembro", 30),
    DEZ ("Dezembro", 31);
    
    private final String nome;
    private final int NumDias;
    
    Meses (String nome, int NumDias){
        this.nome=nome;
        this.NumDias=NumDias;
    }
    
    public String getNome(){
        return nome;
    }
    
    public int getNumDias(){
        return NumDias;
    }
}
