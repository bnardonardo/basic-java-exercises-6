package enummeses;
import java.util.EnumSet;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        System.out.println("De Fevereiro à Agosto:\n");
        
        for (Meses M1 : EnumSet.range(Meses.FEV, Meses.AGO)){
            System.out.printf ("%s - Mês de %s possui %s dias. \n", M1, M1.getNome(), M1.getNumDias());
        }
        /*Meses M1;
        M1=Meses.JAN;
        System.out.printf ("%s - Mês de %s possui %s dias", M1, M1.getNome(), M1.getNumDias());
*/
    }
    
}
